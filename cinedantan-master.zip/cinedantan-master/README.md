<p align="center">
  <a href="https://cinedantan.com">
    <img src="https://cinedantan.com/logo192.png" />
  </a>
</p>

# Hello there!

Cinedantan is a public domain movies streaming webapp.

![](https://cdn.cinedantan.com/github/you-might-like.png)

Whether you're a fan of vintage black and white flicks, classic musicals, or timeless dramas. it's easy and super fast to browse our extensive collection of +2100 movies.

The movies dataset was created by combining multiple sources:
Archive.org, WikiData, Wikipedia, and IMDB.

## Some Features
- Offline search engine
- Create and share your lists
- Continue Watching
- Personalized recommendations
- Casting support
- ...

